/*  CREATING PROCEDURES UpdateOrderDetails */

CREATE PROCEDURE UpdateOrderDetails (
    @OrderID INT,
    @ProductID INT,
    @UnitPrice MONEY = NULL,
    @Quantity INT = NULL,
    @Discount DECIMAL(4,2) = NULL
)
AS
BEGIN
    
    UPDATE Sales.OrderDetails
    SET
        UnitPrice = ISNULL(@UnitPrice, UnitPrice),
        Quantity = ISNULL(@Quantity, Quantity),
        Discount = ISNULL(@Discount, Discount)
    WHERE
        OrderID = @OrderID AND ProductID = @ProductID;

    
    IF @Quantity IS NOT NULL
    BEGIN
        UPDATE Production.Products
        SET UnitsInStock = UnitsInStock - (@Quantity - (SELECT Quantity FROM Sales.OrderDetails WHERE OrderID = @OrderID AND ProductID = @ProductID))
        WHERE ProductID = @ProductID;
    END;

  
    PRINT 'Order details updated successfully.';
END;
GO