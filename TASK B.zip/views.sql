--creating table and our sample data
--Create Customers table
CREATE TABLE Customers (
    CustomerID INT PRIMARY KEY,
    CompanyName VARCHAR(50)
);
GO

-- Create Orders table
CREATE TABLE Orders (
    OrderID INT PRIMARY KEY,
    OrderDate DATE,
    CustomerID INT,
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);
GO

-- Create OrderDetails table
CREATE TABLE OrderDetails (
    OrderDetailID INT PRIMARY KEY,
    OrderID INT,
    ProductID INT,
    Quantity INT,
    UnitPrice DECIMAL(10, 2),
    FOREIGN KEY (OrderID) REFERENCES Orders(OrderID),
    FOREIGN KEY (ProductID) REFERENCES Products(ProductID)
);
GO

-- Create Products table
CREATE TABLE Products (
    ProductID INT PRIMARY KEY,
    ProductName VARCHAR(50),
    QuantityPerUnit VARCHAR(50),
    UnitPrice DECIMAL(10, 2),
    Discontinued BIT,
    SupplierID INT,
    CategoryID INT,
    FOREIGN KEY (SupplierID) REFERENCES Suppliers(SupplierID),
    FOREIGN KEY (CategoryID) REFERENCES Categories(CategoryID)
);
GO

-- Create Suppliers table
CREATE TABLE Suppliers (
    SupplierID INT PRIMARY KEY,
    CompanyName VARCHAR(50)
);
GO

-- Create Categories table
CREATE TABLE Categories (
    CategoryID INT PRIMARY KEY,
    CategoryName VARCHAR(50)
);
GO

-- Insert sample data 
INSERT INTO Customers (CustomerID, CompanyName) VALUES
(1, 'Customer A'),
(2, 'Customer B');
GO

-- Insert sample data into Orders table
INSERT INTO Orders (OrderID, OrderDate, CustomerID) VALUES
(1, '2024-05-01', 1),
(2, '2024-05-02', 2);
GO

-- Insert sample data 
INSERT INTO OrderDetails (OrderDetailID, OrderID, ProductID, Quantity, UnitPrice) VALUES
(1, 1, 1, 5, 10.00),
(2, 1, 2, 3, 20.00),
(3, 2, 1, 2, 10.00);
GO

-- Insert sample data 
INSERT INTO Products (ProductID, ProductName, QuantityPerUnit, UnitPrice, Discontinued, SupplierID, CategoryID) VALUES
(1, 'Product A', '10 boxes', 10.00, 0, 1, 1),
(2, 'Product B', '20 boxes', 20.00, 0, 1, 1);
GO

-- Insert sample data 
INSERT INTO Suppliers (SupplierID, CompanyName) VALUES
(1, 'Supplier A');
GO

-- Insert sample data into Categories table
INSERT INTO Categories (CategoryID, CategoryName) VALUES
(1, 'Category A');
GO

CREATE VIEW vwCustomerOrders AS
SELECT 
    c.CompanyName,
    o.OrderID,
    o.OrderDate,
    od.ProductID,
    p.ProductName,
    od.Quantity,
    od.UnitPrice,
    od.Quantity * od.UnitPrice AS TotalPrice
FROM 
    Orders o
JOIN 
    Customers c ON o.CustomerID = c.CustomerID
JOIN 
    OrderDetails od ON o.OrderID = od.OrderID
JOIN 
    Products p ON od.ProductID = p.ProductID;
GO
-- Create view vwCustomerOrdersYesterday
CREATE VIEW vwCustomerOrdersYesterday AS
SELECT 
    c.CompanyName,
    o.OrderID,
    o.OrderDate,
    od.ProductID,
    p.ProductName,
    od.Quantity,
    od.UnitPrice,
    od.Quantity * od.UnitPrice AS TotalPrice
FROM 
    Orders o
JOIN 
    Customers c ON o.CustomerID = c.CustomerID
JOIN 
    OrderDetails od ON o.OrderID = od.OrderID
JOIN 
    Products p ON od.ProductID = p.ProductID
WHERE 
    o.OrderDate = DATEADD(day, -1, CAST(GETDATE() AS DATE));
GO
-- Create view MyProducts
CREATE VIEW MyProducts AS
SELECT 
    p.ProductID,
    p.ProductName,
    p.QuantityPerUnit,
    p.UnitPrice,
    s.CompanyName AS SupplierName,
    c.CategoryName
FROM 
    Products p
JOIN 
    Suppliers s ON p.ProductID = s.SupplierID  -- Adjust the relationship if necessary
JOIN 
    Categories c ON p.ProductID = c.CategoryID  -- Adjust the relationship if necessary
WHERE 
    p.Discontinued = 0;
GO

SELECT * FROM vwCustomerOrders;
GO

/*to read query 2 */
SELECT * FROM vwCustomerOrdersYesterday;
GO


/*to read query 3*/
SELECT * FROM MyProducts;
GO
