/*  DeleteOrderDetails Procedure*/

CREATE PROCEDURE DeleteOrderDetails (@OrderID INT, @ProductID INT)
AS
BEGIN
  -- Check if the OrderID and ProductID exist in the OrderDetails table
  IF EXISTS (SELECT 1 FROM OrderDetails WHERE OrderID = @OrderID AND ProductID = @ProductID)
  BEGIN
    -- Delete the corresponding record from the OrderDetails table
    DELETE FROM OrderDetails WHERE OrderID = @OrderID AND ProductID = @ProductID;
  END
  ELSE
  BEGIN
    -- Return error code and print an error message if the parameters are invalid
    PRINT 'Invalid parameters. OrderID or ProductID does not exist.';
    RETURN -1;
  END
END;
GO