/*creating sample data and inserting values to it*/
CREATE TABLE Orders (
    OrderID INT PRIMARY KEY,
    OrderDate DATE,
    CustomerID INT
);

-- Create the OrderDetails table
CREATE TABLE OrderDetails (
    OrderDetailID INT PRIMARY KEY,
    OrderID INT,
    ProductID INT,
    Quantity INT,
    FOREIGN KEY (OrderID) REFERENCES Orders(OrderID)
);

-- Create the Products table
CREATE TABLE Products (
    ProductID INT PRIMARY KEY,
    ProductName VARCHAR(50),
    UnitsInStock INT
);

-- Insert sample data into Orders table
INSERT INTO Orders (OrderID, OrderDate, CustomerID) VALUES
(1, '2024-05-01', 101),
(2, '2024-05-02', 102);

-- Insert sample data into OrderDetails table
INSERT INTO OrderDetails (OrderDetailID, OrderID, ProductID, Quantity) VALUES
(1, 1, 1, 5),
(2, 1, 2, 3),
(3, 2, 1, 2);

-- Insert sample data into Products table
INSERT INTO Products (ProductID, ProductName,UnitsInStock) VALUES
(1, 'Product A', 10),
(2, 'Product B', 5);

/*query1*/


CREATE TRIGGER InsteadOfDeleteOrder
ON Orders
INSTEAD OF DELETE
AS
BEGIN
    -- Delete corresponding records in OrderDetails table
    DELETE FROM OrderDetails
    WHERE OrderID IN (SELECT OrderID FROM DELETED);

    -- Delete the order from Orders table
    DELETE FROM Orders
    WHERE OrderID IN (SELECT OrderID FROM DELETED);
END;

/*query 2*/
CREATE TRIGGER BeforeInsertOrderDetails
ON OrderDetails
INSTEAD OF INSERT
AS
BEGIN
    DECLARE @ProductID INT;
    DECLARE @Quantity INT;
    DECLARE @UnitsInStock INT;

    -- Get the ProductID and Quantity from the inserted row
    SELECT @ProductID = ProductID, @Quantity = Quantity
    FROM INSERTED;

    -- Get the current stock for the product
    SELECT @UnitsInStock = UnitsInStock
    FROM Products
    WHERE ProductID = @ProductID;

    -- Check if there is sufficient stock
    IF @UnitsInStock >= @Quantity
    BEGIN
        -- Update the stock
        UPDATE Products
        SET UnitsInStock = UnitsInStock - @Quantity
        WHERE ProductID = @ProductID;

        -- Insert the order details
        INSERT INTO OrderDetails (OrderDetailID, OrderID, ProductID, Quantity)
        SELECT OrderDetailID, OrderID, ProductID, Quantity
        FROM INSERTED;
    END
    ELSE
    BEGIN
        -- Raise an error if there is insufficient stock
        RAISERROR ('Insufficient stock for ProductID %d', 16, 1, @ProductID);
    END;
END;
