/* Creating Procedures  GetOrderDetails */

CREATE PROCEDURE GetOrderDetails (@OrderID INT)
AS
BEGIN
  -- Check if any records exist for the given OrderID
  IF EXISTS (SELECT 1 FROM OrderDetails WHERE OrderID = @OrderID)
  BEGIN
    -- Select all records for the given OrderID
    SELECT * FROM OrderDetails WHERE OrderID = @OrderID;
  END
  ELSE
  BEGIN
    -- Print the error message if no records are found
    PRINT 'The OrderID ' + CAST(@OrderID AS VARCHAR) + ' does not exists';
    -- Return 1 to indicate error
    RETURN 1;
  END
END;
GO