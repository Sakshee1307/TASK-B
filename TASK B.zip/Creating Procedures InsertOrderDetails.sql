/*InsertOrderDetail stored procedure*/

CREATE PROCEDURE InsertOrderDetail (
    @OrderID INT,
    @ProductID INT,
    @UnitPrice MONEY = NULL,
    @Quantity INT,
    @Discount DECIMAL(4,2) = NULL
)
AS
BEGIN
    -- Check if UnitPrice is NULL, if so, get the UnitPrice from the product table
    IF @UnitPrice IS NULL
    BEGIN
        SELECT @UnitPrice = UnitPrice
        FROM Production.Products
        WHERE ProductID = @ProductID;
    END;

    -- Check if Discount is NULL, if so, set Discount to 0
    IF @Discount IS NULL
    BEGIN
        SET @Discount = 0;
    END;

    -- Insert the order details
    INSERT INTO Sales.OrderDetails (
        OrderID,
        ProductID,
        UnitPrice,
        Quantity,
        Discount
    )
    VALUES (
        @OrderID,
        @ProductID,
        @UnitPrice,
        @Quantity,
        @Discount
    );

    -- Check if the order was inserted
    IF @@ROWCOUNT = 1
    BEGIN
        -- Update UnitsInStock for the product
        UPDATE Production.Products
        SET UnitsInStock = UnitsInStock - @Quantity
        WHERE ProductID = @ProductID;

        -- Print success message
        PRINT 'Order placed successfully.';
    END
    ELSE
    BEGIN
        -- Print error message
        PRINT 'Failed to place the order. Please try again.';
    END;
END;
GO